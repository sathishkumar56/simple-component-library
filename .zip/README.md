# simple-component-library
A library of React components created using `create-react-app`.
## Installation
Run the following command:
`npm install simple-component-library
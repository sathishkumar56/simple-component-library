
import React from "react";
import Login from "./lib/TextInput";

import ReactDOM from "react-dom";

ReactDOM.render(<div>Hello world</div>, document.getElementById("root"));
export { Login };